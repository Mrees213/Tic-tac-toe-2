//
//  GridLabel.swift
//  Tic tac toe 2
//
//  Created by Morgan w Rees on 1/13/21.
//

import UIKit

class GridLabel: UILabel {
    var canTap = true
}
